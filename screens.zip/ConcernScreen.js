import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const ConcernScreen = () => {
  const [concern, setConcern] = useState('');

  const handleSubmit = () => {
    // Notify company via email/SMS
    console.log({ concern });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Write your concern</Text>
      <TextInput
        style={styles.textArea}
        placeholder="Enter your concern"
        value={concern}
        onChangeText={setConcern}
        multiline
        numberOfLines={4}
      />
      <Button title="Submit" onPress={handleSubmit} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  label: { fontSize: 16, marginBottom: 5 },
  textArea: { borderWidth: 1, padding: 10, borderRadius: 5, height: 100 },
});

export default ConcernScreen;
