# MyCity_Bangalore
‘My City- Your One Stop Solution’ This application deals with all the special features of our very
own beautiful city – BANGALORE. It has a dashboard which consists of six options namely i)
emergency call ii) famous foods iii) famous attractions iv) current temperature v) how to reach
vi) English to Kannada Translation. It has a great user interface and got an amazing user
experience too. It also has user signup and login feature connected to firebase powered by google.
Backend of the app is entirely managed by itself and require no administrator as such. This app is
very helpful for the people who are visiting Bangalore for the first time and are looking for
something that can give them all the required information about the city at single place. Thus, our
app has a tagline -Your one stop solution. We provide our user A-Z information about the city in
a very handy, storage friendly and all age compatible manner. This App also has a slider nav bar
inspired from Gmail application which allow the users to switch the fragments easily without any
hassle. 
FEW OF THESNAPSHOTS ARE ATTACHED BELOW:
![a5](https://user-images.githubusercontent.com/90666871/178128768-6f5d1e41-072a-4767-a8f5-719baeab20b5.jpeg)![WhatsApp Image 2022-07-08 at 11 04 42 PM](https://user-images.githubusercontent.com/90666871/178128760-74b3411b-cdc2-40ef-a91a-a3cb5ea8654c.jpeg) ![WhatsApp Image 2022-07-08 at 11 27 16 PM](https://user-images.githubusercontent.com/90666871/178128772-f188b73d-94be-4e5c-aa0b-b2694fab14df.jpeg)![WhatsApp Image 2022-07-08 at 11 21 40 PM](https://user-images.githubusercontent.com/90666871/178128782-960d7b90-ea6e-4e80-8383-f7253f3d5215.jpeg)![a3](https://user-images.githubusercontent.com/90666871/178128787-0b323b24-6480-45f5-9a53-1bf1698aaaaf.jpeg)![a1](https://user-images.githubusercontent.com/90666871/178128789-8807b019-e181-4bdf-9453-3bb844d6b853.jpeg)![WhatsApp Image 2022-07-08 at 11 14 41 PM](https://user-images.githubusercontent.com/90666871/178128793-9de554df-b3af-4ddb-8761-976528677fd3.jpeg)
