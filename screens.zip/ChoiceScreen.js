import React from 'react';
import { View, Button, StyleSheet } from 'react-native';

const ChoiceScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Button title="Complaint Rising" onPress={() => navigation.navigate('Complaint')} />
      <Button title="Any Concerns" onPress={() => navigation.navigate('Concern')} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});

export default ChoiceScreen;